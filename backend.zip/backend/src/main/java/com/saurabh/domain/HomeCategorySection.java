package com.saurabh.domain;

public enum HomeCategorySection {
	ELECTRIC_CATEGORIES,
	GRID,
	SHOP_BY_CATEGORIES,
	DEALS

}
