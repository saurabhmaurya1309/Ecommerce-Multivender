package com.saurabh.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.saurabh.config.JwtProvider;
import com.saurabh.domain.AccountStatus;
import com.saurabh.domain.USER_ROLE;
import com.saurabh.domain.VerificationPurpose;
import com.saurabh.exceptions.SellerException;
import com.saurabh.model.Address;
import com.saurabh.model.Seller;
import com.saurabh.model.VerificationCode;
import com.saurabh.repository.AddressRepository;
import com.saurabh.repository.SellerRepository;
import com.saurabh.repository.VerificationCodeRepository;
import com.saurabh.request.SellerSignupRequest;
import com.saurabh.service.SellerService;

@Service
public class SellerServiceImpl implements SellerService {
	private final SellerRepository sellerRepository;
	private final JwtProvider jwtProvider;
	private final PasswordEncoder passwordEncoder;
	private final AddressRepository addressRepository;
	private final VerificationCodeRepository verificationCodeRepository;
	
	

	public SellerServiceImpl(SellerRepository sellerRepository, JwtProvider jwtProvider,PasswordEncoder passwordEncoder, AddressRepository addressRepository, VerificationCodeRepository verificationCodeRepository) {
		this.sellerRepository = sellerRepository;
		this.jwtProvider = jwtProvider;
		this.passwordEncoder=passwordEncoder;
		this.addressRepository = addressRepository;
		this.verificationCodeRepository = verificationCodeRepository;
	}

	@Override
	public Seller getSellerProfile(String jwt) throws Exception {
		String email=jwtProvider.getEmailFromJwtToken(jwt);
		return this.getSellerByEmail(email);
	}


	@Override
	public Seller getSellerById(Long id) throws SellerException {
		
		return sellerRepository.findById(id).orElseThrow(()-> new SellerException("seller not found with id"+id));
	}

	@Override
	public Seller getSellerByEmail(String email) throws Exception {
		Seller seller = sellerRepository.findByEmail(email);
		if(seller==null) {
			throw new Exception("seller not found ....");
		}
		return seller;
	}

	@Override
	public List<Seller> getAllSellers(AccountStatus status) {
		
		return sellerRepository.findByAccountStatus(status);
	}

	@Override
	public Seller updateSeller(Long id, Seller seller) throws Exception {
		Seller existingSeller=this.getSellerById(id);
		if(seller.getSellerName()!=null) {
			existingSeller.setSellerName(seller.getSellerName());
			
		}
		if(seller.getMobile()!=null) {
			existingSeller.setMobile(seller.getMobile());
		}
		if(seller.getEmail()!=null) {
			existingSeller.setEmail(seller.getEmail());
		}
		if(seller.getBusinessDetails()!=null && seller.getBusinessDetails().getBusinessName()!=null) {
			existingSeller.getBusinessDetails().setBusinessName(seller.getBusinessDetails().getBusinessName());
			
			
		}
		
		if(seller.getBankDetails()!=null 
				&& seller.getBankDetails().getAccountHolderName()!=null
				&& seller.getBankDetails().getIfscCode()!=null 
				&& seller.getBankDetails().getAccountNumber()!=null) {
			
			existingSeller.getBankDetails().setAccountHolderName(seller.getBankDetails().getAccountHolderName());
			existingSeller.getBankDetails().setAccountNumber(seller.getBankDetails().getAccountNumber());
			existingSeller.getBankDetails().setIfscCode(seller.getBankDetails().getIfscCode());
			
		}
		if (
			    seller.getPickupAddress() != null
			) {

			    Address existingAddress =
			        existingSeller.getPickupAddress();

			    Address newAddress =
			        seller.getPickupAddress();


			    if (newAddress.getName() != null) {
			        existingAddress.setName(
			            newAddress.getName()
			        );
			    }

			    if (newAddress.getMobile() != null) {
			        existingAddress.setMobile(
			            newAddress.getMobile()
			        );
			    }

			    if (newAddress.getAddress() != null) {
			        existingAddress.setAddress(
			            newAddress.getAddress()
			        );
			    }

			    if (newAddress.getLocality() != null) {
			        existingAddress.setLocality(
			            newAddress.getLocality()
			        );
			    }

			    if (newAddress.getCity() != null) {
			        existingAddress.setCity(
			            newAddress.getCity()
			        );
			    }

			    if (newAddress.getState() != null) {
			        existingAddress.setState(
			            newAddress.getState()
			        );
			    }

			    if (newAddress.getPincode() != null) {
			        existingAddress.setPincode(
			            newAddress.getPincode()
			        );
			    }

			}
		if(seller.getGSTIN()!=null) {
			existingSeller.setGSTIN(seller.getGSTIN());
		}
		return sellerRepository.save(existingSeller);
	}

	@Override
	public void deleteSeller(Long id) throws Exception {
		Seller seller=getSellerById(id);
		sellerRepository.delete(seller);
		
	}

	

	@Override
	public Seller updateSellerAccountStatus(Long sellerId, AccountStatus status) throws Exception {
		Seller seller=getSellerById(sellerId);
		seller.setAccountStatus(status);
		return sellerRepository.save(seller);
	}

	@Override
	public void createSeller(SellerSignupRequest req) throws Exception {

	    VerificationCode verificationCode =
	            verificationCodeRepository
	                    .findByEmailAndPurpose(
	                            req.getEmail(),
	                            VerificationPurpose.EMAIL_VERIFICATION
	                    );

	    if (verificationCode == null) {
	        throw new Exception("OTP not found");
	    }

	    if (!verificationCode.getOtp().equals(req.getOtp())) {
	        throw new Exception("Invalid OTP");
	    }

	    if (verificationCode.getExpiryTime() == null
	            || verificationCode.getExpiryTime()
	                    .isBefore(LocalDateTime.now())) {

	        throw new Exception("OTP expired");
	    }

	    Seller existingSeller =
	            sellerRepository.findByEmail(
	                    req.getEmail()
	            );

	    if (existingSeller != null) {
	        throw new Exception(
	                "Seller already registered"
	        );
	    }

	    Address savedAddress =
	            addressRepository.save(
	                    req.getPickupAddress()
	            );

	    Seller seller = new Seller();

	    seller.setSellerName(
	            req.getSellerName()
	    );

	    seller.setEmail(
	            req.getEmail()
	    );

	    seller.setPassword(
	            passwordEncoder.encode(
	                    req.getPassword()
	            )
	    );

	    seller.setMobile(
	            req.getMobile()
	    );

	    seller.setGSTIN(
	            req.getGSTIN()
	    );

	    seller.setPickupAddress(
	            savedAddress
	    );

	    seller.setBankDetails(
	            req.getBankDetails()
	    );

	    seller.setBusinessDetails(
	            req.getBusinessDetails()
	    );

	    seller.setRole(
	            USER_ROLE.ROLE_SELLER
	    );

	    seller.setEmailVerified(true);

	    seller.setAccountStatus(
	            AccountStatus.PENDING_VERIFICATION
	    );
	    sellerRepository.save(seller);

	    verificationCodeRepository.delete(
	            verificationCode
	    );
	}

}
